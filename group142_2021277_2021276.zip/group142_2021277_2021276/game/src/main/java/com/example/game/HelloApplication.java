package com.example.game;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.effect.Light;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("hello-view.fxml"));

        Scene scene = new Scene(root);
        stage.setTitle("Stick-Hero");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}


interface Collectible {
    void applyEffect(StickHero stickHero);
}

interface Obstacle {
    boolean isColliding(StickHero stickHero);
}

abstract class Reward implements Collectible {
    private int type;
    private int position;

    public Reward(int type, int position) {

    }

    public Reward() {

    }

    public abstract void applyEffect(StickHero stickHero);
}

class CherryReward extends Reward {
    public CherryReward(int position) {
        super();

    }

    public void applyEffect(StickHero stickHero) {

    }
}



abstract class Platform {
    private int width;
    private int position;

    public Platform(int width, int position) {

    }

    public Platform() {

    }

    public abstract boolean isWithinRange(int xPosition);
}

class StaticPlatform extends Platform {
    public StaticPlatform(int width, int position) {

    }

    public boolean isWithinRange(int xPosition) {
        return false;
    }
}


abstract class Obstacle1 extends Platform implements Obstacle {
    public Obstacle1(int width, int position) {
        super();

    }

    public Obstacle1() {

    }

    public abstract boolean isColliding(StickHero stickHero);
}

class Gap extends Obstacle1 {
    public Gap(int position, int width) {
        super();

    }

    @Override
    public boolean isWithinRange(int xPosition) {
        return false;
    }

    public boolean isColliding(StickHero stickHero) {


        return false;
    }
}


class Level {
    private List<Platform> platforms;
    private List<Collectible> rewards;
    private List<Obstacle1> obstacles;

    public Level(List<Platform> platforms, List<Collectible> rewards, List<Obstacle1> obstacles) {
    }
}

class Game {
    private StickHero stickHero;
    private Level currentLevel;
    private int score;

    public Game() {

    }


    public void gameover() {

    }

    public void startGame() {

    }

    public void update() {

    }

    public void render() {

    }
}

class Gameover{
    private void displayGameOverMessage() {


    }

    public void promptRestart() {
    }
}

class StickHero {
    private boolean flipped = false;
    private int lives = 3;
    private int score = 0;
    private int cherries = 0;
    private Light.Point position;
    private int stickLength;

    public StickHero() {

    }

    public void move() {

    }

    public void extendStick(int length) {

    }

    public void collectReward(Reward reward) {

    }

    public void revive() {

    }

    public void saveProgress() {

    }

    public void flip() {

    }
}