package com.example.game;

import static org.junit.jupiter.api.Assertions.*;

import com.example.game.StickHeroGame;
import javafx.embed.swing.JFXPanel;
import javafx.stage.Stage;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class StickHeroGameTest {

    @BeforeAll
    static void init() {
        // Initialize JavaFX for headless testing
        JFXPanel jfxPanel = new JFXPanel();
    }

    @Test
    void testGenerateGoldenCoins() {
        StickHeroGame game = new StickHeroGame();
        // Mock platform positions
        double platformX = 100;
        double platformY = 200;
        double nextPlatformX = 200;
        double nextPlatformY = 300;

        // Mock adding a golden coin
        game.generateGoldenCoins(platformX, platformY, nextPlatformX, nextPlatformY);
        assertEquals(1, game.getGoldenCoins().size());
    }


    @Test
    void testMoveCharacter() {
        StickHeroGame game = new StickHeroGame();
        game.setCharacterX(100);
        game.setCharacterY(200);
        game.setNextPlatformX(300);
        game.setPlatformY(300);

        // Mock moving the character
        game.moveCharacter(50);
        assertEquals(150, game.getCharacterY());
    }

    @Test
    void testReviveGame() {
        StickHeroGame game = new StickHeroGame();
        game.setScore(10);

        // Mock reviving the game
        game.reviveGame(new Stage());
        assertEquals(5, game.getScore());
        assertFalse(game.isGameOver());
    }
}