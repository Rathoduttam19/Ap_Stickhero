package com.example.game;

import javafx.animation.KeyFrame;
import javafx.animation.PauseTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
// import javafx.embed.swing.JFXPanel;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
//import eu.lestard.assertj.javafx.api.Assertions;
//import eu.lestard.assertj.javafx.api.AssertionsForClassTypes;
//import eu.lestard.junit.FXTest;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertTrue;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

public class StickHeroGame extends Application {
    static int MIN_PLATFORM_DISTANCE = 20;
    private static int MAX_PLATFORM_DISTANCE = 100;
    private static final int CHARACTER_WIDTH = 7;
    private static final int CHARACTER_HEIGHT = 20;
    private static final int MIN_PLATFORM_WIDTH = 50;
    private static final int MAX_PLATFORM_WIDTH = 70;
    private  int PLATFORM_WIDTH = generateRandomWidth();

    private Rectangle character;
    Line stick;
    private Stage primaryStage;  // Add this line
    private List<GoldenCoin> goldenCoins = new ArrayList<>();
    private int collectedCoins = 0;
    boolean isStretching = false;
    private Label scoreLabel;
    private double stickLength = 0;
    boolean isMoving = false;
    double characterX;
    private static final double JUMP_VELOCITY = -10.0;
    private static final double JUMP_DURATION = 500.0;

    private boolean isJumping = false;
    private double jumpStartTime;
    double characterY;
    double platformX;
    private Scene scene;
    private Scene gameScene;

    double nextPlatformX;
    private double platformY;
    boolean isStickCreated = false;
    Timeline stickExtensionTimeline;
    private Group root;
    private int score = 0;
    boolean isGameOver = false;
    private long pressTime;
    private double currentStickLength;
    private double nextPlatformY;
    private Scene startScene;
    private double totalDistanceCovered = 0;
    private boolean isScreenMoving = false; // Track if the screen is currently moving
    private Text scoreText;
    private static final double GRAVITY = 0.5;
    private Rectangle topBorder;
    private Rectangle bottomBorder;
    private Rectangle leftBorder;
    private Rectangle rightBorder;
    private boolean gameOverPrinted = false;
    boolean gameOverDisplayed = false;

    public static int getMinPlatformDistance() {
        return MIN_PLATFORM_DISTANCE;
    }

    public static void setMinPlatformDistance(int minPlatformDistance) {
        MIN_PLATFORM_DISTANCE = minPlatformDistance;
    }

    public static int getMaxPlatformDistance() {
        return MAX_PLATFORM_DISTANCE;
    }

    public static void setMaxPlatformDistance(int maxPlatformDistance) {
        MAX_PLATFORM_DISTANCE = maxPlatformDistance;
    }

    public int getPLATFORM_WIDTH() {
        return PLATFORM_WIDTH;
    }

    public void setPLATFORM_WIDTH(int PLATFORM_WIDTH) {
        this.PLATFORM_WIDTH = PLATFORM_WIDTH;
    }

    public Rectangle getCharacter() {
        return character;
    }

    public void setCharacter(Rectangle character) {
        this.character = character;
    }

    public Line getStick() {
        return stick;
    }

    public void setStick(Line stick) {
        this.stick = stick;
    }

    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public List<GoldenCoin> getGoldenCoins() {
        return goldenCoins;
    }

    public void setGoldenCoins(List<GoldenCoin> goldenCoins) {
        this.goldenCoins = goldenCoins;
    }

    public int getCollectedCoins() {
        return collectedCoins;
    }

    public void setCollectedCoins(int collectedCoins) {
        this.collectedCoins = collectedCoins;
    }

    public boolean isStretching() {
        return isStretching;
    }

    public void setStretching(boolean stretching) {
        isStretching = stretching;
    }

    public Label getScoreLabel() {
        return scoreLabel;
    }

    public void setScoreLabel(Label scoreLabel) {
        this.scoreLabel = scoreLabel;
    }

    public double getStickLength() {
        return stickLength;
    }

    public void setStickLength(double stickLength) {
        this.stickLength = stickLength;
    }

    public boolean isMoving() {
        return isMoving;
    }

    public void setMoving(boolean moving) {
        isMoving = moving;
    }

    public double getCharacterX() {
        return characterX;
    }

    public void setCharacterX(double characterX) {
        this.characterX = characterX;
    }

    public boolean isJumping() {
        return isJumping;
    }

    public void setJumping(boolean jumping) {
        isJumping = jumping;
    }

    public double getJumpStartTime() {
        return jumpStartTime;
    }

    public void setJumpStartTime(double jumpStartTime) {
        this.jumpStartTime = jumpStartTime;
    }

    public double getCharacterY() {
        return characterY;
    }

    public void setCharacterY(double characterY) {
        this.characterY = characterY;
    }

    public double getPlatformX() {
        return platformX;
    }

    public void setPlatformX(double platformX) {
        this.platformX = platformX;
    }

    public Scene getScene() {
        return scene;
    }

    public void setScene(Scene scene) {
        this.scene = scene;
    }

    public Scene getGameScene() {
        return gameScene;
    }

    public void setGameScene(Scene gameScene) {
        this.gameScene = gameScene;
    }

    public double getNextPlatformX() {
        return nextPlatformX;
    }

    public void setNextPlatformX(double nextPlatformX) {
        this.nextPlatformX = nextPlatformX;
    }

    public double getPlatformY() {
        return platformY;
    }

    public void setPlatformY(double platformY) {
        this.platformY = platformY;
    }

    public boolean isStickCreated() {
        return isStickCreated;
    }

    public void setStickCreated(boolean stickCreated) {
        isStickCreated = stickCreated;
    }

    public Timeline getStickExtensionTimeline() {
        return stickExtensionTimeline;
    }

    public void setStickExtensionTimeline(Timeline stickExtensionTimeline) {
        this.stickExtensionTimeline = stickExtensionTimeline;
    }

    public Group getRoot() {
        return root;
    }

    public void setRoot(Group root) {
        this.root = root;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public boolean isGameOver() {
        return isGameOver;
    }

    public void setGameOver(boolean gameOver) {
        isGameOver = gameOver;
    }

    public long getPressTime() {
        return pressTime;
    }

    public void setPressTime(long pressTime) {
        this.pressTime = pressTime;
    }

    public double getCurrentStickLength() {
        return currentStickLength;
    }

    public void setCurrentStickLength(double currentStickLength) {
        this.currentStickLength = currentStickLength;
    }

    public double getNextPlatformY() {
        return nextPlatformY;
    }

    public void setNextPlatformY(double nextPlatformY) {
        this.nextPlatformY = nextPlatformY;
    }

    public Scene getStartScene() {
        return startScene;
    }

    public void setStartScene(Scene startScene) {
        this.startScene = startScene;
    }

    public double getTotalDistanceCovered() {
        return totalDistanceCovered;
    }

    public void setTotalDistanceCovered(double totalDistanceCovered) {
        this.totalDistanceCovered = totalDistanceCovered;
    }

    public boolean isScreenMoving() {
        return isScreenMoving;
    }

    public void setScreenMoving(boolean screenMoving) {
        isScreenMoving = screenMoving;
    }

    public Text getScoreText() {
        return scoreText;
    }

    public void setScoreText(Text scoreText) {
        this.scoreText = scoreText;
    }

    public Rectangle getTopBorder() {
        return topBorder;
    }

    public void setTopBorder(Rectangle topBorder) {
        this.topBorder = topBorder;
    }

    public Rectangle getBottomBorder() {
        return bottomBorder;
    }

    public void setBottomBorder(Rectangle bottomBorder) {
        this.bottomBorder = bottomBorder;
    }

    public Rectangle getLeftBorder() {
        return leftBorder;
    }

    public void setLeftBorder(Rectangle leftBorder) {
        this.leftBorder = leftBorder;
    }

    public Rectangle getRightBorder() {
        return rightBorder;
    }

    public void setRightBorder(Rectangle rightBorder) {
        this.rightBorder = rightBorder;
    }

    public boolean isGameOverPrinted() {
        return gameOverPrinted;
    }

    public void setGameOverPrinted(boolean gameOverPrinted) {
        this.gameOverPrinted = gameOverPrinted;
    }

    public boolean isGameOverDisplayed() {
        return gameOverDisplayed;
    }

    public void setGameOverDisplayed(boolean gameOverDisplayed) {
        this.gameOverDisplayed = gameOverDisplayed;
    }

    @Override
    public void start(Stage primaryStage) {
        Group startRoot = new Group();
        this.primaryStage = primaryStage;
        startScene = new Scene(startRoot, 600, 400);
        // Loading the image for the background
        Image backgroundImage = new Image("file:///C:\\Users\\hp\\IdeaProjects\\group142_2021277_2021276\\game\\src\\main\\java\\Assets\\image.jpg");
        // Creating a background using the loaded image
        Rectangle background = new Rectangle(0, 0, 600, 400);
        ImagePattern backgroundPattern = new ImagePattern(backgroundImage);
        background.setFill(backgroundPattern);

        // Creating the start button with reduced size, curved edges, black color, and a white text label
        double buttonWidth = 180 * 0.7;
        double buttonHeight = 100 * 0.7;

        Rectangle startButton = new Rectangle(250, 200, buttonWidth, buttonHeight);
        startButton.setArcWidth(20);
        startButton.setArcHeight(20);
        startButton.setFill(Color.BLACK);

        Label startLabel = new Label("Start");
        startLabel.setTextFill(Color.WHITE);
        startLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14)); // Bold font
        startLabel.setLayoutX(250 + (buttonWidth - startLabel.getWidth()) / 2 - 5); // Center the label horizontally
        startLabel.setLayoutY(200 + (buttonHeight - startLabel.getHeight()) / 2 - 5); // Center the label vertically
        startButton.setOnMouseClicked(event -> startGame(primaryStage));
        startRoot.getChildren().addAll(background, startButton, startLabel);
        primaryStage.setScene(startScene);
        primaryStage.show();
    }

    public void startGame(Stage primaryStage) {
        root = new Group();
        scene = new Scene(root, 600, 400);
        characterX = PLATFORM_WIDTH - CHARACTER_WIDTH;
        characterY = 320;
        platformX = 200;
        nextPlatformX = platformX;
        platformY = 300;

        Image backgroundImage = new Image("file:C:\\Users\\hp\\IdeaProjects\\group142_2021277_2021276\\game\\src\\main\\java\\Assets\\image.jpg");
        ImageView backgroundImageView = new ImageView(backgroundImage);

// Set the size and position of the image view
        backgroundImageView.setFitWidth(600); // Adjust width as needed
        backgroundImageView.setFitHeight(400); // Adjust height as needed
        backgroundImageView.setX(0); // Adjust X position as needed
        backgroundImageView.setY(0); // Adjust Y position as needed
        root.getChildren().add(backgroundImageView);


        Rectangle startingPlatform = new Rectangle(0, characterY + CHARACTER_HEIGHT, PLATFORM_WIDTH, 100);
        startingPlatform.setFill(Color.BLACK);
        root.getChildren().add(startingPlatform);

        character = new Rectangle(characterX, characterY, CHARACTER_WIDTH, CHARACTER_HEIGHT);
        double arcWidth = 10; // Adjust the arc width as needed
        double arcHeight = 10; // Adjust the arc height as needed
        character.setArcWidth(arcWidth);
        character.setArcHeight(arcHeight);
        character.setFill(Color.BLUE);
        stick = new Line();
        stick.setStroke(Color.BLACK);
        stick.setStrokeWidth(2); // Set the stick's width
        // Inside the startGame method
        topBorder = new Rectangle(0, 0, scene.getWidth(), 3);
        bottomBorder = new Rectangle(0, scene.getHeight() - 3, scene.getWidth(), 3);
        leftBorder = new Rectangle(0, 0, 3, scene.getHeight());
        rightBorder = new Rectangle(scene.getWidth() - 3, 0, 3, scene.getHeight());

// Set the borders' color and add them to the root group
        Color borderColor = Color.BLACK;
        topBorder.setFill(borderColor);
        bottomBorder.setFill(borderColor);
        leftBorder.setFill(borderColor);
        rightBorder.setFill(borderColor);
        root.getChildren().addAll(character, stick, topBorder, bottomBorder, leftBorder, rightBorder); // Add the stick Line object to the root group
        createScoreboard();

        scene.setOnKeyPressed(event -> {
            if (!isGameOver) {
                if (event.getCode() == KeyCode.SPACE && !isMoving) {
                    if (!isStretching) {
                        isStretching = true;
                        pressTime = System.currentTimeMillis();
                        generateStick();
                        extendStick();
                    }
                } else if (event.getCode() == KeyCode.K && isMoving) {
                    flipCharacter();
                }
            }
        });
        scene.setOnKeyReleased(event -> {
            if (!isGameOver) {
                if (event.getCode() == KeyCode.SPACE && isStretching && !isMoving) {
                    isStretching = false;
                    stopStickExtension();
                    createBridge();

                    if (!isScreenMoving) {
                        moveScreenLeft();
                        moveBordersRight();
                        moveScoreboardRight();
                        moveImageRight(backgroundImageView);
                        isScreenMoving = true;
                    }
                } else if (event.getCode() == KeyCode.ENTER && isJumping) {

                }
            }
        });
        primaryStage.setScene(scene);
        primaryStage.show();

        generateNextPlatform();
    }
    // Method to move the game screen towards the left by a specified distance
    public void moveScreenLeft() {
        final double movementSpeed = 0.3; // Adjust the speed as needed

        Timeline screenMoveTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            totalDistanceCovered += movementSpeed;
            root.setTranslateX(-totalDistanceCovered);
        }));
        screenMoveTimeline.setCycleCount(Timeline.INDEFINITE); // Run the timeline indefinitely
        screenMoveTimeline.play();
    }
    public void moveImageRight(ImageView imageView) {
        final double movementSpeed = 0.3; // Set the movement speed

        Timeline imageMoveTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            imageView.setX(imageView.getX() + movementSpeed); // Move the image towards the right
        }));
        imageMoveTimeline.setCycleCount(Timeline.INDEFINITE); // Run the timeline indefinitely
        imageMoveTimeline.play();
    }
    // Add this method to generate a random width
    public static int generateRandomWidth() {
        Random random = new Random();
        return random.nextInt(MAX_PLATFORM_WIDTH - MIN_PLATFORM_WIDTH + 1) + MIN_PLATFORM_WIDTH;
    }
    public void moveBordersRight() {
        moveTopBorderRight();
        moveBottomBorderRight();
        moveLeftBorderRight();
        moveRightBorderRight();
    }

    // Method to move the top border towards the right
    public void moveTopBorderRight() {
        final double movementSpeed = 0.3; // Adjust the speed as needed

        Timeline topBorderMoveTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            topBorder.setX(topBorder.getX() + movementSpeed); // Move the top border towards the right
        }));
        topBorderMoveTimeline.setCycleCount(Timeline.INDEFINITE); // Run the timeline indefinitely
        topBorderMoveTimeline.play();
    }
    // Method to move the bottom border towards the right
    public void moveBottomBorderRight() {
        final double movementSpeed = 0.3; // Adjust the speed as needed

        Timeline bottomBorderMoveTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            bottomBorder.setX(bottomBorder.getX() + movementSpeed); // Move the bottom border towards the right
        }));
        bottomBorderMoveTimeline.setCycleCount(Timeline.INDEFINITE); // Run the timeline indefinitely
        bottomBorderMoveTimeline.play();
    }
    // Method to move the left border towards the right
    public void moveLeftBorderRight() {
        final double movementSpeed = 0.3; // Adjust the speed as needed

        Timeline leftBorderMoveTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            leftBorder.setX(leftBorder.getX() + movementSpeed); // Move the left border towards the right

            // Check if the character touches the left border
            if (characterX <= leftBorder.getX()) {
                endGame();
            }
        }));
        leftBorderMoveTimeline.setCycleCount(Timeline.INDEFINITE);
        leftBorderMoveTimeline.play();
    }
    // Method to move the right border towards the right
    public void moveRightBorderRight() {
        final double movementSpeed = 0.3; // Adjust the speed as needed
        Timeline rightBorderMoveTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            rightBorder.setX(rightBorder.getX() + movementSpeed); // Move the right border towards the right
        }));
        rightBorderMoveTimeline.setCycleCount(Timeline.INDEFINITE); // Run the timeline indefinitely
        rightBorderMoveTimeline.play();
    }
    public void createScoreboard() {
        scoreText = new Text("Score: 0");
        scoreText.setFill(Color.BLACK);
        scoreText.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        scoreText.setLayoutX(20); // Adjust X position as needed
        scoreText.setLayoutY(30); // Adjust Y position as needed
        root.getChildren().add(scoreText); // Add scoreText to the root node
    }

    public void flipCharacter() {
        if (scene != null && character != null) {
            double sceneHeight = scene.getHeight();
            if (!Double.isNaN(sceneHeight)) {
                double rotationCenterX = characterX + CHARACTER_WIDTH / 2;
                double rotationCenterY = characterY + CHARACTER_HEIGHT - stickLength;

                Rotate flip = new Rotate(180, rotationCenterX, rotationCenterY);
                character.getTransforms().add(flip);

                // Adjust the character's Y position based on the stick length
                characterY += stickLength;
                character.setY(characterY);
            }
        }
    }

    public void moveScoreboardRight() {
        final double movementSpeed = 0.3; // Adjust the speed as needed

        Timeline scoreboardMoveTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            scoreText.setX(scoreText.getX() + movementSpeed); // Move the scoreboard towards the right
        }));
        scoreboardMoveTimeline.setCycleCount(Timeline.INDEFINITE); // Run the timeline indefinitely
        scoreboardMoveTimeline.play();
    }
    public void generateGoldenCoins(double platformX, double platformY, double nextPlatformX, double nextPlatformY) {
        Random random = new Random();

        // Generate coins between the end of the current platform and the start of the next platform
        double start = platformX + PLATFORM_WIDTH;
        double end = nextPlatformX;
        double coinX = start + random.nextDouble() * (end - start);

        // Adjust coinY to ensure it's below the height of the platforms
        double coinY = platformY + CHARACTER_HEIGHT + random.nextDouble() * (nextPlatformY - (platformY + CHARACTER_HEIGHT));

        GoldenCoin goldenCoin = new GoldenCoin(coinX, coinY);
        root.getChildren().add(goldenCoin);
        goldenCoins.add(goldenCoin);
    }
    public void generateNextPlatform() {
        PLATFORM_WIDTH = generateRandomWidth();
        int newDistance = generateRandomDistance() + PLATFORM_WIDTH;
        nextPlatformX += newDistance;
        nextPlatformY = characterY + CHARACTER_HEIGHT;

        Rectangle platform = new Rectangle(nextPlatformX - PLATFORM_WIDTH, nextPlatformY, PLATFORM_WIDTH, 100);
        platform.setFill(Color.BLACK);
        root.getChildren().add(platform);

        // Generate golden coins between the current and next platforms
        generateGoldenCoins(platformX, platformY, nextPlatformX, nextPlatformY);
        MIN_PLATFORM_DISTANCE += 5;
        MAX_PLATFORM_DISTANCE += 10;
    }
    public void checkCoinCollision() {
        Iterator<GoldenCoin> iterator = goldenCoins.iterator();
        while (iterator.hasNext()) {
            GoldenCoin coin = iterator.next();
            if (character.getBoundsInParent().intersects(coin.getBoundsInParent())) {
                // Remove the collected coin from the root and the list
                root.getChildren().remove(coin);
                iterator.remove();
                collectedCoins++;
                updateScoreLabel();
            }
        }
    }
    class GoldenCoin extends Circle {
        private static final double COIN_RADIUS = 10;

        public GoldenCoin(double x, double y) {
            super(x, y, COIN_RADIUS);
            setFill(Color.GOLD);
            setStroke(Color.GOLD); // Add a black border around the coin
            setStrokeWidth(2.0); // Set the border width
        }
    }

    public void updateScore() {
        scoreText.setText("Score: " + (score + collectedCoins));
    }


    public int generateRandomDistance() {
        Random random = new Random();
        return random.nextInt(MAX_PLATFORM_DISTANCE - MIN_PLATFORM_DISTANCE + 1) +MIN_PLATFORM_DISTANCE;
    }
    public  void extendStick() {
        stickExtensionTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            if (isStretching) {
                long elapsedTime = System.currentTimeMillis() - pressTime;
                currentStickLength = elapsedTime * 0.1; // Adjust the multiplication factor for desired extension speed
                stick.setStartX(characterX + CHARACTER_WIDTH / 2);
                stick.setStartY(characterY + CHARACTER_HEIGHT);
                stick.setEndX(characterX + CHARACTER_WIDTH / 2);
                stick.setEndY(characterY + CHARACTER_HEIGHT - currentStickLength);
            }
        }));
        stickExtensionTimeline.setCycleCount(Timeline.INDEFINITE);
        stickExtensionTimeline.play();
    }
    public void generateStick() {
        stick = new Line();
        stick.setStroke(Color.BLACK);
        stick.setStrokeWidth(2);
        stick.setStartX(characterX + CHARACTER_WIDTH / 2);
        stick.setStartY(characterY + CHARACTER_HEIGHT);
        stick.setEndX(characterX + CHARACTER_WIDTH / 2);
        stick.setEndY(characterY + CHARACTER_HEIGHT);
        root.getChildren().add(stick);
    }

    public void resetStick() {
        stickLength = 0;

        // Remove the stick from the group
        if (stick != null && stick.getParent() != null) {
            ((Group) stick.getParent()).getChildren().remove(stick);
        }
        // Ensure the stick is marked as not created to enable the creation of a new stick
        isStickCreated = false;

        // Set the stick's start and end positions to the character's current position
        stick = new Line();
        stick.setStroke(Color.BLACK);
        stick.setStrokeWidth(2);
        stick.setStartX(characterX + CHARACTER_WIDTH / 2);
        stick.setStartY(characterY + CHARACTER_HEIGHT);
        stick.setEndX(characterX + CHARACTER_WIDTH / 2);
        stick.setEndY(characterY + CHARACTER_HEIGHT);
        ((Group) character.getParent()).getChildren().add(stick);
    }

    public void createBridge() {
        stopStickExtension();

        stickLength = currentStickLength; // Update stick length when the key is released

        if (stickLength >= MIN_PLATFORM_DISTANCE / 2) {
            // If the stick length is sufficient, move the character across the bridge
            PauseTransition delay = new PauseTransition(Duration.millis(900));
            delay.setOnFinished(event -> moveCharacter(stickLength));
            delay.play();
        } else {
            // If the stick length is not sufficient, the character falls off
            //fallOff();
        }

        rotateStickClockwise90();
    }

    public void stopStickExtension() {
        if (stickExtensionTimeline != null) {
            stickExtensionTimeline.stop();
            stickLength = currentStickLength;
        }
    }
    public void rotateStickClockwise90() {
        final int totalRotationSteps = 90;
        final double rotationStep = 1.0;

        double stickStartX = stick.getStartX(); // Starting X-coordinate of the stick
        double stickStartY = stick.getStartY(); // Starting Y-coordinate of the stick

        double xDiff = stickStartX - nextPlatformX;
        double yDiff = stickStartY - nextPlatformY;

        double rotationAngle = Math.atan2(yDiff, xDiff);
        double totalRotation = Math.toDegrees(rotationAngle);

        Rotate rotation = new Rotate(0, stickStartX, stickStartY);
        stick.getTransforms().add(rotation);

        Timeline rotateTimeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            double currentRotation = rotation.getAngle();
            if (currentRotation < 90) {
                rotation.setAngle(currentRotation + rotationStep);
                double newX = stickStartX - stickLength * Math.cos(Math.toRadians(currentRotation + rotationStep));
                double newY = stickStartY - stickLength * Math.sin(Math.toRadians(currentRotation + rotationStep));
                stick.setEndX(newX);
                stick.setEndY(newY);
            }
        }));

        rotateTimeline.setCycleCount(totalRotationSteps);
        rotateTimeline.play();
    }

    private void rotateStickBy90() {
        Rotate rotation = new Rotate(90, stick.getStartX(), stick.getStartY());
        stick.getTransforms().add(rotation);
    }


    public void moveCharacter(double distance) {
        // isJumping = false; // Reset jumping flag when moving
        isMoving = true;
        score++;
        scoreText.setText("Score: " + score);
        double previousCharacterY = characterY; // Store the previous Y position

        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(10), e -> {
            if (!isMoving) {
                // Apply gravity if the character is not moving
                if (!isCollidingWithGround()) {
                    characterY += GRAVITY;
                }
            }
            // Check if the character's Y position changes
            if (characterY != previousCharacterY) {
                // End the game if the character's Y position changes
                endGame();
            }
            // Check if the character's Y position changes
            if (characterX < nextPlatformX - PLATFORM_WIDTH) {
                characterX += 1; // Move character towards the next platform
                character.setX(characterX);
                character.setY(characterY); // Update character's Y position
            } else {
                isMoving = false;
                resetStick(); // Reset the stick

                // Create a new stick and start rotating it
                if (!isStickCreated) {
                    stick.setRotate(0); // Reset stick rotation
                    stick.setStartX(nextPlatformX - PLATFORM_WIDTH / 2);
                    stick.setEndX(nextPlatformX - PLATFORM_WIDTH / 2);
                    stick.setStartY(characterY + CHARACTER_HEIGHT);
                    stick.setEndY(characterY + CHARACTER_HEIGHT);

                    generateStick(); // Generate a new stick
                    rotateStickClockwise90(); // Start rotating the stick

                    isStickCreated = true; // Mark the stick as created
                }

                generateNextPlatform(); // Generate the next platform

                // Check for coin collision after generating the next platform
                checkCoinCollision();
            }

            if (characterY >= scene.getHeight() - CHARACTER_HEIGHT) {
                // Character touched the bottom border, end the game
                endGame();
            }

        }));

        timeline.setCycleCount((int) distance); // Set cycle count based on the distance to move
        timeline.play();
    }


    public void showGameOverScreen(int totalScore) {
        Group gameOverRoot = new Group();

        // Create a label for the game over message
        Label gameOverLabel = new Label("Game Over");
        gameOverLabel.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        gameOverLabel.setTextFill(Color.RED);
        gameOverLabel.setLayoutX(200);
        gameOverLabel.setLayoutY(200);

        // Create a label to display the total score
        Label totalScoreLabel = new Label("Total Score: " + totalScore);
        totalScoreLabel.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        totalScoreLabel.setTextFill(Color.BLACK);
        totalScoreLabel.setLayoutX(250);
        totalScoreLabel.setLayoutY(250);

        // Create a "Revive" button
        Button reviveButton = new Button("Revive");
        reviveButton.setLayoutX(250);
        reviveButton.setLayoutY(300);
        reviveButton.setOnAction(event -> reviveGame(primaryStage)); // Pass the primaryStage to resetGame

        // Create Quit button
        Button quitButton = new Button("Quit");
        quitButton.setLayoutX(400);
        quitButton.setLayoutY(300);
        quitButton.setOnAction(event -> {
            System.exit(0); // This exits the application.
        });
        // Add the label and button to the group
        gameOverRoot.getChildren().addAll(gameOverLabel,totalScoreLabel,quitButton, reviveButton);

        // Create a scene for the game over screen
        PauseTransition delay = new PauseTransition(Duration.millis(300)); // 3000 milliseconds = 3 seconds
        delay.setOnFinished(event -> {
            Scene gameOverScene = new Scene(gameOverRoot, 600, 400);
            Stage primaryStage = (Stage) root.getScene().getWindow();
            primaryStage.setScene(gameOverScene);
            primaryStage.show();
        });
        delay.play();

    }

    public void reviveGame(Stage primaryStage) {
        if (score >= 5) {
            // Deduct 5 points for revival
            score -= 5;
            updateScoreLabel();

            // Reset and restart the game
            resetGame();
            startGame(primaryStage);
            // Add a 2-second delay
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(event -> {
                // Code to be executed after the delay
                // (e.g., additional actions or UI updates)
            });
            pause.play();

        } else {
            System.out.println("Not enough score to revive.");
        }
    }
    public void updateScoreLabel() {
        Platform.runLater(() -> {
            scoreText.setText("Score: " + (score));
        });
    }

    public void resetGame() {
        // Clear existing elements
        root.getChildren().clear();

        // Reset character position
        characterX = PLATFORM_WIDTH - CHARACTER_WIDTH;
        characterY = 320;
        character.setX(characterX);
        character.setY(characterY);

        // Reset platform-related variables
        nextPlatformX = platformX = 200;
        platformY = 300;

        // Add the background image to the scene directly
        Image backgroundImage = new Image("file:/C:\\Users\\satwi\\OneDrive\\Desktop\\Ap\\group142_2021277_2021276\\game\\src\\main\\resources\\com\\example\\game\\image.jpg");
        ImageView backgroundImageView = new ImageView(backgroundImage);
        backgroundImageView.setFitWidth(600);
        backgroundImageView.setFitHeight(400);
        backgroundImageView.setX(0);
        backgroundImageView.setY(0);
        ((Group) scene.getRoot()).getChildren().add(backgroundImageView);;



        // Generate a starting platform
        Rectangle startingPlatform = new Rectangle(0, characterY + CHARACTER_HEIGHT, PLATFORM_WIDTH, 100);
        startingPlatform.setFill(Color.BLACK);
        root.getChildren().add(startingPlatform);

        // Reset other game state variables as needed
        isMoving = false;
        isStretching = false;
        isJumping = false;
        isStickCreated = false;
        isScreenMoving = false;
        gameOverPrinted = false;
        gameOverDisplayed = false;


        // Clear collected coins
        goldenCoins.clear();
        updateScoreLabel();

        // Restart the game
        generateNextPlatform();
        isGameOver = false;

        // Reset screen translation
        totalDistanceCovered = 0;
        root.setTranslateX(0);

        // Reset borders
        leftBorder.setX(0);
        topBorder.setX(0);
        bottomBorder.setX(0);
        rightBorder.setX(scene.getWidth() - 3);

        // Reset score label position
        scoreText.setX(20);

        // Show the game scene
        primaryStage.setScene(scene);
    }

    public void endGame() {
        if (!gameOverDisplayed) {
            gameOverDisplayed = true;
            isGameOver = true;
            showGameOverScreen(score);
            // Perform additional actions based on your game's requirements.
        }
    }

    public boolean isCollidingWithGround() {
        for (javafx.scene.Node node : root.getChildren()) {
            if (node instanceof Rectangle && node != character) {
                Rectangle platform = (Rectangle) node;
                if (character.getBoundsInParent().intersects(platform.getBoundsInParent())) {
                    platformY = platform.getY(); // Update platform Y position
                    return true; // Collision detected
                }
            }
        }
        return false; // No collision detected
    }

    public static void main(String[] args) {
        launch(args);
    }
}